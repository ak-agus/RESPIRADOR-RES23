# Reespirator

[Documentación y hardware](https://gitlab.com/coronavirusmakers/reespirator-doc)

## Resources

* [Arduino Reference](https://www.arduino.cc/reference/en/)
* [Arduino Best Practices and Gotchas](https://www.theatreofnoise.com/2017/05/arduino-ide-best-practices-and-gotchas.html)
* [C++ Best Practices (Gitbook)](https://lefticus.gitbooks.io/cpp-best-practices/content/)

## Team

### Testers

* *Añadir aquí nombres de usuarios*

### Maintainers

* *Añadir aquí nombres de usuarios*

### Developers

* *Añadir aquí nombres de usuarios*
